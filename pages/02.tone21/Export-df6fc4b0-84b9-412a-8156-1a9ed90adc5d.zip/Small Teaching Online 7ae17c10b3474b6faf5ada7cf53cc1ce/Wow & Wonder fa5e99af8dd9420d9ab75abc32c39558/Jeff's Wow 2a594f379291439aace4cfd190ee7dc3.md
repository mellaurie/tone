# Jeff's Wow

Chapter: Chapter 1
Type: Wow

First of all, forgive my ignorance, but I was surprised to learn that many post secondary educators have had little to no training in teaching. Not a requirement for teaching? What the what!???

The idea of using a "...story that illustrates your pedagogical thinking...". 

Taking a concept that students would already be familiar with and applying it to new/abstract ideas gives clear vision, comprehension and retention. Parables people. Jesus was on to something.

Darby reinforces the concept of backwards design with the idea of going on a trip and the importance of wheel alignment. She's eating her own dog food. I like it.