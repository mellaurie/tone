# Karen's Wonder

Assign: Karen Roeck
Chapter: Chapter 2
Thought: What is the secret sauce for helping faculty understand that providing regular formative feedback and guiding learning through engagement is not "extra work" on top of what "really counts" (their content)?
Type: Wonder