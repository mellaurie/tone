# Mel's Wonder

Assign: Mel L
Chapter: Chapter 2
Thought: On the idea of conditional release, Darby notes not to overdo it.  I wonder what's the sweet spot.  How many times can you use it?  What are the best approaches to using this strategically?
Type: Wonder