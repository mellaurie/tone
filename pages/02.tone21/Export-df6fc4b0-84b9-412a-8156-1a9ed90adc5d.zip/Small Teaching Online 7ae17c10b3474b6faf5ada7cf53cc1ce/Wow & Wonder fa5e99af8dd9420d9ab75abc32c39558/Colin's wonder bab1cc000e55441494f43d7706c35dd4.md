# Colin's wonder

Assign: Colin Madland
Chapter: Chapter 1
Type: Wonder

I wonder what it will take to change the metaphor. Online learning is so different from the classroom that using the classroom as a metaphor is going to break down very quickly and lead people to simply reproduce and amplify all the inequities of the classroom.