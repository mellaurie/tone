# Dave's Wonder

Chapter: Chapter 1
Type: Wonder

So many Faculty I have worked with are really determined to mimic the f2f experience of their traditional classroom - aside from offering up an explanation, I often wonder if there is a more effective way to help Faculty better understand the importance of being explicit in an online environment and helping them understand the role "structure" plays in designing an explicit and intuitive experience that focuses on meaningful learning for students.