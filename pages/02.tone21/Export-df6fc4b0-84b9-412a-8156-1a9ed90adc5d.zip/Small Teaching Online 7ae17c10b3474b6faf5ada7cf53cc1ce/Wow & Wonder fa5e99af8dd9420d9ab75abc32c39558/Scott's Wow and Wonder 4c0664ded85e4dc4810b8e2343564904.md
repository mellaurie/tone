# Scott's Wow and Wonder

Chapter: Chapter 1
Comment: Good point on "social supports" for orienting class.  Is there is a TIP guide we can develop for faculty.
Type: Wow