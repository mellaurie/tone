# Dave's Wow

Chapter: Chapter 1
Type: Wow

Not so much a "wow" but more of a reinforcement of how important it is to be explicit in every facet of course design in an online environment. Recent conversations in my learning pods have really highlighted the nuances of communication that are taken for granted in a f2f environment by faculty and students alike. Being explicit in each element of course design is such a critical component in course design.