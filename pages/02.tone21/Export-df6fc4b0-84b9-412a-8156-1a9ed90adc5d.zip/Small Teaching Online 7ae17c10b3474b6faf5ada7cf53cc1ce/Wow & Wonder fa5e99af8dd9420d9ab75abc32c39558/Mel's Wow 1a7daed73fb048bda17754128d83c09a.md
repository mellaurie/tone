# Mel's Wow

Assign: Mel L
Chapter: Chapter 2
Thought: "The net doesn't assign points based on your performance.  It provides feedback." (Darby referencing Jose Brown, p. 38)
Formative feedback can be, should be, nonevaluative.  It should let students know where they are at and where they need to go - i.e. address the learning gap. In class activities (like Jamboards) can be an informal way and an opportunity to check their learning or even self-assess.
Type: Wow