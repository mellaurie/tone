# Dave's Wonder

Chapter: Chapter 2
Thought: I wonder how the Conditional Release function can be more effectively leveraged to support some of the concepts of personalized feedback from Christina Bieber's presentation. In my breakout room many of the Faculty mentioned how it was just not possible to provide the type of engagement she suggested - I wonder how we can shift "thinking" so that faculty can understand that engagement does not have to be limited to just intensive one-on-one time and that we have these "tools" available to support student learning. 
Type: Wonder