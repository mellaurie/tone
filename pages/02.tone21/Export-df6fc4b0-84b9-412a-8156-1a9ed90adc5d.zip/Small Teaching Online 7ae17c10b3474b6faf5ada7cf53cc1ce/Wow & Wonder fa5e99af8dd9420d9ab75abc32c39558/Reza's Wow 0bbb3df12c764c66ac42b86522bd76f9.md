# Reza's Wow

Chapter: Chapter 1
Type: Wow

I liked the idea of reflection activity on course objectives at the beginning of the course and by the end of the course. Also giving the option to students to record their reflections in a video or audio clip.