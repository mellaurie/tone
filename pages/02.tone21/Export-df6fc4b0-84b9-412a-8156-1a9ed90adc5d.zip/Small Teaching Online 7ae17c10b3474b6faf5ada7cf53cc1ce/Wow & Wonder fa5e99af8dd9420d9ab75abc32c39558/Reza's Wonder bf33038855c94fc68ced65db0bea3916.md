# Reza's Wonder

Chapter: Chapter 1
Type: Wonder

I'm wondering if the process of importing courses into different sections are aligned with the idea of designing purposeful course? How can we ensure a well-designed course can serve best for all teaching styles?