# Small Teaching Online

Author: Flower Darby
Created by: Mel L
Mention Yourself When You've Read It: Karen Roeck
Type: Book

Small Teaching Online book club

- Give a "wow" and a "wonder" from each chapter
- Mar 2 = Ch 1 (pp. 5-26)
- Mar 9 = Ch 2 (pp. 27-46)
- Mar 16 = Ch 3 (pp. 47-70)
- Mar 23 = Ch 4 (pp. 75-106)
- Mar 30 = Ch 5 (pp. 107-130)
- Apr 6 = Ch 6 (pp. 131-151)
- Apr 13 = Ch 7 (pp. 157-178)
- Apr 21 = Ch 8 (pp. 179-198)
- Apr 28 = Ch 9 (pp. 199-226)

[Wow & Wonder](Small%20Teaching%20Online%207ae17c10b3474b6faf5ada7cf53cc1ce/Wow%20&%20Wonder%20fa5e99af8dd9420d9ab75abc32c39558.csv)